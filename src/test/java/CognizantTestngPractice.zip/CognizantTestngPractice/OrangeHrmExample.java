package CognizantTestngPractice;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class OrangeHrmExample {
	WebDriver driver;
	WebDriverWait wait;
	SoftAssert as;
	@BeforeClass
	public void beforeClass() {
		driver=new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().window().maximize();
        wait=new WebDriverWait(driver, Duration.ofSeconds(5));
        as=new SoftAssert();
	}
	
	@Test(priority = 0)
	public void userName() {
		WebElement username=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"username\"]")));
		username.sendKeys("Admin");
		as.assertEquals(username.getText(), "Admin");
		as.assertAll();
	}
	
	@Test(priority = 1)
	public void passWord() {
		
		WebElement password=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"password\"]")));
		password.sendKeys("Admin");
		as.assertEquals(password.getText(), "admin123");
		as.assertAll();
	}
	
	@Test(priority = 2)
	public void Submit() {
		WebElement Login=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Login ']")));
		Login.click();
		
		as.assertAll();
		
	}
	
	@Test(priority = 3)
	public void signup() {
	    as.assertEquals(driver.getCurrentUrl(), "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
	    System.out.println("Signup successfully");
	    as.assertAll();
	    }
	
	@Test(dependsOnMethods = {"userName","passWord","Submit","signup"})
	public void Login() {
		System.out.println("Login succesfully");
		
	}
	@AfterClass(alwaysRun = true)
	public void Final() throws InterruptedException {
		Thread.sleep(5000);
		System.out.println("page closed successfully");
		driver.quit();
	}
	

}
