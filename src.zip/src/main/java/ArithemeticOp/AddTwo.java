package ArithemeticOp;

import java.util.Scanner;

public class AddTwo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int sum=a+b;
		System.out.print("The summation of the two numbers is :"+sum);

	}

}
