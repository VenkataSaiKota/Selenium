package Basic;

import java.util.Scanner;

public class ScannerInput {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the name :");
		String name=sc.nextLine();
		System.out.print(name);
		

	}

}
