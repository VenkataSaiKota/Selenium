package Basic;

public class BasicInt {

	public static void main(String[] args) {
	
		int a=10;
		System.out.print("The value of a is:"+a);
		

	}

}
