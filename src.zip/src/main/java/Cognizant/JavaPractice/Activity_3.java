package Cognizant.JavaPractice;

public class Activity_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int Java=100;
		int Sql=90;
		int Jdbc=79;
		int Total=Java+Sql+Jdbc;
		double Avg=(double)Total/3;
		
		System.out.println(Avg);
		System.out.print(Total);
		
		
	}

}
