package Cognizant.JavaPractice;

import java.util.Scanner;

public class Activity_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String name=s.nextLine();
		int age=s.nextInt();
		System.out.print("My name is :"+name+"and age :"+age);
		
		

	}

}
