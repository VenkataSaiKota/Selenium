package Cognizant.JavaPractice;

import java.util.Scanner;

public class Activity_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
//		String PassWord=sc.next();
		int i=3;
		while(i>0) {
			System.out.print("You have "+i+" attempts to enter the correct password");
		}

	}

}
