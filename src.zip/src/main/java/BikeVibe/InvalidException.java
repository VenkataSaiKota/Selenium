package BikeVibe;

public class InvalidException  extends Exception{
	public InvalidException(String message) {
		super(message);
	}

}
