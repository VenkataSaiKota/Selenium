package string;

import java.util.Scanner;

public class Frequencywords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the paragraph");
		String str=sc.nextLine();
		String[] words=str.split(" ");
		for(int i=0;i<words.length;i++) {
			
		}
	
	}

}
