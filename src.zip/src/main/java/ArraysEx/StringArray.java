package ArraysEx;

public class StringArray {

	public static void main(String[] args) {
		String[] a = {"One", "Two", "Three", "Four"};
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
			i++;
			
		}
		

	}

}
