package ArraysEx;

public class RemDuplicate {

	public static void main(String[] args) {
		int[] arr= {9,10,8,3,6,4,8,5};
		

	}

}
