package Loops;

public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=5;
		int pow=2;
		int i=1;
		int res=1;
		while(i<=pow) {
			res=res*num;
			i++;
		}
		System.out.println("Power of a number is "+res);
		
		

	}

}
