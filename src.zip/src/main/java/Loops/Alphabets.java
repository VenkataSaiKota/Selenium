package Loops;

public class Alphabets {

	public static void main(String[] args) {
	
		for(int i=0;i<26;i++) {
			char ch=(char) ((char)(i)+97);
			System.out.print(ch+" ");
			
		}
		System.out.println();
		for(int i=0;i<26;i++) {
			char ch=(char) ((char)(i)+65);
			System.out.print(ch+" ");
			
		}

	}

}
