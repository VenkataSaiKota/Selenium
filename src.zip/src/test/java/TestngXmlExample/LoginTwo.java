package TestngXmlExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class LoginTwo extends Login {
	@Test
	public void config() {
		SoftAssert as=new SoftAssert();
		WebElement username=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"username\"]")));
		username.sendKeys("Admin");
		WebElement password=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name=\"password\"]")));
		password.sendKeys("admin123");
		WebElement Login=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Login ']")));
		Login.click();
		as.assertEquals(driver.getCurrentUrl(), "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
		as.assertAll();
	}
	
//	@Test(dependsOnMethods = "config")
//	public void sucess() {
//		System.out.println("Sucess");
//	}
	
}
