package TestngXmlExample;


import java.time.Duration;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;



public class Login extends BaseClass {
	@BeforeTest
	public void connectDriver()
	{
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().window().maximize();
        wait=new WebDriverWait(driver, Duration.ofSeconds(5));
	}
	@AfterTest
	public void disconnect() {
		System.out.println("Disconnect succesfully");
	}
	

}
