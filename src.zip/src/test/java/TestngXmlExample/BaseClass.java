package TestngXmlExample;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class BaseClass {
	
	static WebDriver driver;
    WebDriverWait wait;
	@BeforeSuite
	public void setup() {
		driver=new ChromeDriver();
			}
	@AfterSuite
	public void end() throws InterruptedException
	{   Thread.sleep(3000);
		driver.quit();
	}

}
