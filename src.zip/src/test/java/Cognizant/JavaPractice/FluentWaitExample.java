package Cognizant.JavaPractice;

public class FluentWaitExample {

}
