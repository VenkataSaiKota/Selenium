package Cognizant.JavaPractice;

import org.testng.annotations.Test;

public class TestngExample 
{
   @Test
   public void Testngmethod()
   {
	   
   }
}
